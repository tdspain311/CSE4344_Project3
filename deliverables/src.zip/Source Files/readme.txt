"""
Computer Networks
CSE 4344
TEAM: 404
Programming Assignment 3, Project A
Distance Vector Routing Protocol Simulation
"""

We experienced difficulty connecting different hosts together due to UTA's firewall. The project was not detailed enough so we had to simulate a lot of things. 
For example, We randomly selected the distance between the different nodes. The distances are described in our source code.

Most people in our team had Senior design obligations and work obligations. Not being able to meet regularly really pushed us back to test our connections. 
Assumption:
For our project, we are assuming there will be only 5 nodes one per each person. The user will then input their own ip addresses and they will specify thier own host number. 
The validation of ip addresses is not checked. 
All users are on a ad hoc wifi hotspot 